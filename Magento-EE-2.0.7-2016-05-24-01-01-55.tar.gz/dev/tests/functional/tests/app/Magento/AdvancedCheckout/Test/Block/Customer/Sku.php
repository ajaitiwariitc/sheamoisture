<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\AdvancedCheckout\Test\Block\Customer;

/**
 * Customer Order By SKU form.
 */
class Sku extends \Magento\AdvancedCheckout\Test\Block\Sku\AbstractSku
{
    //
}
